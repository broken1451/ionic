export const environment = {
  production: true,
  url: 'https://api.themoviedb.org/3',
  apiKey: '1865f43a0549ca50d341dd9ab8b29f49',
  imgPath: 'https://image.tmdb.org/t/p'
};
