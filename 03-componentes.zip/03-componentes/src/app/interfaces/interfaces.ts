export interface Componente {
    icon: string;
    name: string;
    redirectTo: string;
}
